// app/recipes/[id]/page.js
'use client';
import Image from 'next/image';
import Link from 'next/link';
import { recipes, isLoggedIn } from '../../../lib/data';
import { useParams } from 'next/navigation';

export default function RecipeDetail() {
  const { id } = useParams();
  const recipe = recipes.find(r => r.id === parseInt(id));
  
  if (!recipe) {
    return <div>Recipe not found</div>;
  }

  return (
    <div className="recipe-detail container">
      {isLoggedIn && (
        <div className="auth-buttons">
          <Link href="/login" className="btn">Login/Signup</Link>
        </div>
      )}
      
      <h1>{recipe.title}</h1>
      
      <Image 
        src={recipe.image} 
        alt={recipe.title} 
        width={800} 
        height={400}
        priority
      />
      
      <div className="recipe-section">
        <h2>Ingredients</h2>
        <ul>
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))}
        </ul>
      </div>
      
      <div className="recipe-section">
        <h2>Steps</h2>
        <ol>
          {recipe.steps.map((step, index) => (
            <li key={index}>{step}</li>
          ))}
        </ol>
      </div>
      
      {recipe.additionalInfo && (
        <div className="recipe-section">
          <h2>Additional Information</h2>
          <p>{recipe.additionalInfo}</p>
        </div>
      )}
    </div>
  );
}