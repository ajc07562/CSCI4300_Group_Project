import { NextResponse } from 'next/server';
import connectMongoDB from '../../../config/mongodb';
import Recipe from '../../../models/Recipe';

// GET
export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    console.log('Connecting to DB...');
    await connectMongoDB();

    console.log('Fetching recipe with ID:', params.id);
    const recipe = await Recipe.findById(params.id).exec();

    if (!recipe) {
      console.log('Recipe not found.');
      return NextResponse.json({ error: 'Recipe not found' }, { status: 404 });
    }

    console.log('Recipe found:', recipe);
    return NextResponse.json(recipe);
  } catch (err) {
    console.error('GET route failed:', err);
    return NextResponse.json({ error: 'Failed to fetch recipe' }, { status: 500 });
  }
}


// PUT
export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { title, description, image } = await req.json();
    await connectMongoDB();
    await Recipe.findByIdAndUpdate(params.id, {
      title,
      description,
      image,
    }).exec(); // ✅ clean
    return NextResponse.json({ message: 'Recipe updated' }, { status: 200 });
  } catch (err) {
    console.error('PUT error:', err);
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 });
  }
}

// DELETE
export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    await Recipe.findByIdAndDelete(params.id).exec();
    return NextResponse.json({ message: 'Recipe deleted' }, { status: 200 });
  } catch (err) {
    console.error('DELETE error:', err);
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
  }
}
