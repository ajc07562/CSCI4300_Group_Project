// app/recipes/page.tsx
'use client';
import { useState } from 'react';
import { recipes, isLoggedIn } from '../../lib/data';
import RecipeCard from '../../components/RecipeCard';

export default function RecipesPage() {
  const [selected, setSelected] = useState('');

  // Options in the dropdown based on login status
  const recipeOptions = isLoggedIn
    ? recipes // All 6
    : recipes.slice(0, 3); // Only first 3

  // Show selected recipe only, or all dropdown options if none selected
  const filteredRecipes = selected
    ? recipes.filter((r) => r.title === selected)
    : recipeOptions;

  return (
    <div className="px-4 py-6">
      <h1 className="text-2xl font-bold mb-4 text-center">Explore Recipes</h1>

      <label htmlFor="recipe-select" className="block text-lg font-semibold mb-2">
        Choose a recipe:
      </label>

      <select
        id="recipe-select"
        value={selected}
        onChange={(e) => setSelected(e.target.value)}
        className="w-full md:w-1/2 p-2 border border-gray-300 rounded-md mb-6"
      >
        <option value="">-- Select a recipe --</option>
        {recipeOptions.map((recipe) => (
          <option key={recipe.id} value={recipe.title}>
            {recipe.title}
          </option>
        ))}
      </select>

      {selected === '' && (
        <p className="text-gray-500 text-sm mb-4">You can also view all recipes by leaving the dropdown unselected.</p>
      )}

      <div className="recipe-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecipes.map((recipe) => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}
      </div>
    </div>
  );
}
