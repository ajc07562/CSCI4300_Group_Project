// app/recipes/add/page.js
import RecipeForm from '../../../components/RecipeForm';

export default function AddRecipe() {
  return <RecipeForm type="add" />;
}