// app/api/search/route.ts
export async function POST(req: Request) {
    const { query } = await req.json();
  
    const apiKey = 'b1a3206262e744e6935dffc691e665ef';
    const url = `https://api.spoonacular.com/recipes/complexSearch?query=${encodeURIComponent(query)}&number=10&apiKey=${apiKey}`;
  
    const res = await fetch(url);
    const data = await res.json();
  
    return Response.json(data);
  }
  