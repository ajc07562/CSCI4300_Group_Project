'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useAuth } from '../context/AuthContext';

export default function RecipeCard({ recipe }) {
  const { isLoggedIn } = useAuth();

  const handleEdit = () => {
    window.location.href = `/recipes/edit/${recipe.id}`;
  };

  const handleDelete = async () => {
    const confirmDelete = window.confirm('Are you sure you want to delete this recipe?');
    if (!confirmDelete) return;

    const res = await fetch(`/api/recipes/${recipe.id}`, {
      method: 'DELETE',
    });

    if (res.ok) {
      alert('Recipe deleted!');
      window.location.reload();
    } else {
      alert('Failed to delete recipe.');
    }
  };

  return (
    <div className="recipe-card">
      <Image 
        src={recipe.image} 
        alt={recipe.title} 
        width={300} 
        height={200}
        priority
      />
      <div className="recipe-card-content">
        <h3>{recipe.title}</h3>
        <p>{recipe.description}</p>

        <Link href={`/recipes/${recipe.id}`} className="btn">
          See Recipe
        </Link>

        {isLoggedIn && (
          <div className="mt-2 flex gap-2">
            <button onClick={handleEdit} className="btn">Edit</button>
            <button onClick={handleDelete} className="btn btn-secondary">Delete</button>
          </div>
        )}
      </div>
    </div>
  );
}
