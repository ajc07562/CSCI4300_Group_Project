'use client';
import { useState } from 'react';

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);

  const handleSearch = async () => {
    const res = await fetch('/api/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });
    const data = await res.json();
    setResults(data.results || []);
  };

  return (
    <div className="flex flex-col items-start gap-4 p-4">
      <div className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for a recipe..."
          className="border px-2 py-1 rounded"
        />
        <button onClick={handleSearch} className="btn">Search</button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {results.map((recipe) => (
          <a
          key={recipe.id}
          href={`/api-recipe/${recipe.id}`}
          className="no-underline text-inherit"
        >
          <div className="border p-2 rounded shadow w-full hover:bg-gray-100 transition">
            <p className="font-semibold mb-2">{recipe.title}</p>
            <img src={recipe.image} alt={recipe.title} className="w-full h-auto rounded" />
          </div>
        </a>        
        ))}
      </div>
    </div>
  );
}

